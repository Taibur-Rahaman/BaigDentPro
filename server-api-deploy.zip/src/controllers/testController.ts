import { type Request, type Response, type NextFunction } from 'express';
import { prisma } from '../index.js';
import { verifySupabaseConnection } from '../config/supabase.js';

type TestTableRow = {
  id: number;
  name: string;
};

class HttpError extends Error {
  status: number;

  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

let tableReady = false;

export async function ensureTestTableExists(): Promise<void> {
  if (tableReady) return;

  await prisma.$executeRawUnsafe(`
    CREATE TABLE IF NOT EXISTS public.test_table (
      id BIGSERIAL PRIMARY KEY,
      name TEXT NOT NULL
    );
  `);

  tableReady = true;
}

export async function createTestRecord(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const name = typeof req.body?.name === 'string' ? req.body.name.trim() : '';
    if (!name) {
      throw new HttpError(400, 'name is required');
    }

    await ensureTestTableExists();
    const rows = await prisma.$queryRaw<TestTableRow[]>`
      INSERT INTO public.test_table (name)
      VALUES (${name})
      RETURNING id, name
    `;

    res.status(201).json({ success: true, data: rows[0] ?? null });
  } catch (error) {
    next(error);
  }
}

export async function readTestRecords(_req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    await ensureTestTableExists();
    const rows = await prisma.$queryRaw<TestTableRow[]>`
      SELECT id, name
      FROM public.test_table
      ORDER BY id DESC
    `;
    res.status(200).json({ success: true, data: rows });
  } catch (error) {
    next(error);
  }
}

export async function updateTestRecord(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const id = Number.parseInt(req.params.id, 10);
    const name = typeof req.body?.name === 'string' ? req.body.name.trim() : '';

    if (!Number.isFinite(id) || id <= 0) {
      throw new HttpError(400, 'id must be a positive integer');
    }
    if (!name) {
      throw new HttpError(400, 'name is required');
    }

    await ensureTestTableExists();
    const rows = await prisma.$queryRaw<TestTableRow[]>`
      UPDATE public.test_table
      SET name = ${name}
      WHERE id = ${id}
      RETURNING id, name
    `;

    if (!rows.length) {
      throw new HttpError(404, `test_table row ${id} not found`);
    }

    res.status(200).json({ success: true, data: rows[0] });
  } catch (error) {
    next(error);
  }
}

export async function deleteTestRecord(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const id = Number.parseInt(req.params.id, 10);
    if (!Number.isFinite(id) || id <= 0) {
      throw new HttpError(400, 'id must be a positive integer');
    }

    await ensureTestTableExists();
    const rows = await prisma.$queryRaw<TestTableRow[]>`
      DELETE FROM public.test_table
      WHERE id = ${id}
      RETURNING id, name
    `;

    if (!rows.length) {
      throw new HttpError(404, `test_table row ${id} not found`);
    }

    res.status(200).json({ success: true, data: rows[0] });
  } catch (error) {
    next(error);
  }
}

export async function testSystemStatus(_req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const supabase = await verifySupabaseConnection();
    await ensureTestTableExists();
    res.status(200).json({
      success: true,
      supabase,
      testTableReady: true,
    });
  } catch (error) {
    next(error);
  }
}
